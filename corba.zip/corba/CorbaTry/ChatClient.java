package chat;
import jdk.Client;
import jdk.Stubs;
import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import org.omg.CORBA.Object;
import org.omg.CORBA.ORB;
/** AWT-based client for chat service over CORBA.
  */ 
public class ChatClient extends Frame implements ChatterOperations, Client {
  /** joins the crowd.
      This is in the main thread. Apparently, ORBacus cannot obtain a stub
      in one thread and use it in another (NullPointer in delegate.is_local);
      therefore, this routine forwards the messages.
    */
  public void use (Stubs sender, ORB orb, Object chat) throws Exception {
    // Chatter chatter = new Chatter_Tie(this);
    // orb.connect(chatter);
    ChatterOperations tie =
                           (ChatterOperations)sender.tie(orb, "chat.Chatter", this);
    Chatter chatter = (Chatter)sender.activate(orb, tie);

    ChatterHolder ch = new ChatterHolder(chatter);
    ((Chat)chat).join(ch);
    crowd = ch.value;
   
    // do not terminate -- that would destroy the ORB
    Thread.currentThread().join();
  }
  protected Chatter crowd;

  protected TextArea ta = new TextArea();
  protected TextField tf = new TextField();

  { add(ta, BorderLayout.CENTER); ta.setEditable(false);
 
    if (System.getProperty("os.name").indexOf("Mac") >= 0) { // MacOS X kludge
      java.awt.Panel p = new java.awt.Panel(new BorderLayout());
        p.add(tf, BorderLayout.CENTER);
      add(p, BorderLayout.SOUTH);
    } else
      add(tf, BorderLayout.SOUTH);

    tf.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent ae) {
        crowd.tell(tf.getText()); tf.selectAll();
      }
    });
   
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
         System.exit(0);
      }
    });
   
    pack(); show(); tf.requestFocus();
  }

  public void tell (String message) {
    ta.append(message+"\n");
  }
}
