package chat;
import jdk.Server;
import jdk.Service;
import chat.ChatPackage.Botch;
import java.util.Vector; // change me??
import org.omg.CORBA.ORB;
/** implements chat service over CORBA.
    Creates individual Chatter service for each client.
  */
public class ChatService extends Vector implements ChatOperations, Service {
  /** need to know my server and orb to create servers.
    */
  public void use (Server sender, ORB orb) {
    this.sender = sender; this.orb = orb;
  }
  protected Server sender;
  protected ORB orb;
  /** create a person to multiplex utterances.
    */
  public synchronized void join (ChatterHolder withMe) throws Botch { // inout
    try {
      // withMe.value = new Chatter_Tie(new Person(withMe.value));
      // orb.connect(withMe.value);
      ChatterOperations tie = (ChatterOperations)sender.tie(orb, "chat.Chatter",
                                                          new Person(withMe.value));
      withMe.value = (Chatter)sender.activate(orb, tie);
    } catch (Exception e) { e.printStackTrace(); throw new Botch(e.toString()); }
  }
  /** implements message queue to a single person in the room.
    */
  public class Person extends Vector implements ChatterOperations, Runnable {
    private final Chatter partner;
    /** add myself to room, start thread to dequeue messages to me.
      */
    Person (Chatter partner) {
      this.partner = partner; ChatService.this.addElement(this);
      new Thread(this).start();
    }
    /** queue message with each person (including myself) in the room.
      */
    public void tell (String message) {
      synchronized(ChatService.this) {
        for (int n = 0; n < ChatService.this.size(); ++ n) {
          Person person = (Person)ChatService.this.elementAt(n);
          synchronized(person) {
             person.addElement(message); person.notify();
          }
        }
      }
    }
    /** dequeue messages to me.
      */
    public void run () {
      for (;;) {
        String message;
        synchronized(this) {
          while (size() == 0)
            try { wait(); } catch (InterruptedException e) { }
          message = (String)firstElement(); removeElementAt(0);
        }
        try {
          partner.tell(message);
        } catch (Throwable t) { break; }
      }
      ChatService.this.removeElement(this);
    }
  }
}
