package chat;
import jdk.Client;
import jdk.Stubs;
import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import org.omg.CORBA.Object;
import org.omg.CORBA.ORB;

import org.omg.CosNaming.*; // HelloClient will use the naming service.
import org.omg.CosNaming.NamingContextPackage.*;
import org.omg.CORBA.*;     // All CORBA applications need these classes.
import org.omg.PortableServer.*;   
import org.omg.PortableServer.POA;


public class ChatClient extends Frame implements ChatterOperations, Client 
{
  
  public void use (Stubs sender, ORB orb, Object chat) throws Exception {
    
    ChatterOperations tie =
                           (ChatterOperations)sender.tie(orb, "chat.Chatter", this);
    Chatter chatter = (Chatter)sender.activate(orb, tie);

    ChatterHolder ch = new ChatterHolder(chatter);
    ((Chat)chat).join(ch);
    crowd = ch.value;
   
    
    Thread.currentThread().join();
  }
  protected Chatter crowd;

  protected TextArea ta = new TextArea();
  protected TextField tf = new TextField();

  { add(ta, BorderLayout.CENTER); ta.setEditable(false);
 
    if (System.getProperty("os.name").indexOf("Mac") >= 0) { 
      java.awt.Panel p = new java.awt.Panel(new BorderLayout());
        p.add(tf, BorderLayout.CENTER);
      add(p, BorderLayout.SOUTH);
    } else
      add(tf, BorderLayout.SOUTH);

    tf.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent ae) {
        crowd.tell(tf.getText()); tf.selectAll();
      }
    });
   
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
         System.exit(0);
      }
    });
   
    pack(); show(); tf.requestFocus();
  }

  public void tell (String message) {
    ta.append(message+"\n");
  }

    public static void main(String args[])
    {
	try {
	    ORB orb = ORB.init(args, null);
	    POA rootpoa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
            rootpoa.the_POAManager().activate();

	    org.omg.CORBA.Object objRef = 
                     orb.resolve_initial_references("NameService");
	    NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);

	    String name = "Chat";
	    chatImpl = ChatHelper.narrow(ncRef.resolve_str(name));
	    
	    ChatCallbackServant chatCallbackImpl = new ChatCallbackServant();
	    chatCallbackImpl.setORB(orb);

	    org.omg.CORBA.Object ref = rootpoa.servant_to_reference(chatCallbackImpl);
	    ChatCallback cref = ChatCallbackHelper.narrow(ref);

	    String chat = chatImpl.say(cref, "\n Hello \n");
	    System.out.println(ciao);

	} catch(Exception e){
	    System.out.println("ERROR : " + e);
	    e.printStackTrace(System.out);
	} 
	}
	}