package jdk;
import org.omg.CORBA.ORB;
/** how to get and manage stubs.
  */
public interface Stubs {
  /** @param iface interface name, iface and iface+Operations must exist.
      @param service service object.
      @return tie for service.
    */
  Object tie (ORB orb, String iface, Object service) throws Exception;
  /** @return activated stub for a tie obtained from {@link #tie}.
    */
  org.omg.CORBA.Object activate (ORB orb, Object tie) throws Exception;
  /** inactivates a tie obtained from {@link #tie}.
    */
  void deactivate (ORB orb, Object tie) throws Exception;
}
