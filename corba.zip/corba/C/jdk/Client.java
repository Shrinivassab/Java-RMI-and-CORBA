package jdk;
import org.omg.CORBA.Object;
import org.omg.CORBA.ORB;
/** how to be a generically started client.
  */
public interface Client {
  /** generic starter calls this method to let client act.
    */
  void use (Stubs sender, ORB orb, Object stub) throws Exception;
}
