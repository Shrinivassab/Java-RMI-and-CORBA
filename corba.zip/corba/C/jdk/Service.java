package jdk;
import org.omg.CORBA.ORB;
/** how to be a generically started service.
  */
public interface Service {
  /** if service implements this interface,
      generic starter calls this method once to let service manage stubs.
    */
  void use (Server sender, ORB orb);
}
