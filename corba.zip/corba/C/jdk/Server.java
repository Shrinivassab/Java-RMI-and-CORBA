package jdk;
import org.omg.CORBA.Object;
/** how to get and manage stubs.
  */
public interface Server extends Stubs {
  /** @return stub for root service.
    */
  Object stub ();
}
